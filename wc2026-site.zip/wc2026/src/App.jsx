import { useState, useEffect } from "react";

const YT_CHANNEL = "https://www.youtube.com/@Budro26worldcup";

const GROUPS = {
  A: { teams: [{ name: "Mexico", flag: "🇲🇽", w:1,d:0,l:0,gf:2,ga:0,pts:3 }, { name: "South Africa", flag: "🇿🇦", w:0,d:1,l:0,gf:1,ga:1,pts:1 }, { name: "South Korea", flag: "🇰🇷", w:0,d:1,l:0,gf:1,ga:1,pts:1 }, { name: "Poland", flag: "🇵🇱", w:0,d:0,l:1,gf:0,ga:2,pts:0 }] },
  B: { teams: [{ name: "Switzerland", flag: "🇨🇭", w:1,d:0,l:0,gf:2,ga:0,pts:3 }, { name: "Canada", flag: "🇨🇦", w:0,d:1,l:0,gf:1,ga:1,pts:1 }, { name: "Bosnia & Herz.", flag: "🇧🇦", w:0,d:1,l:0,gf:1,ga:1,pts:1 }, { name: "Qatar", flag: "🇶🇦", w:0,d:0,l:1,gf:0,ga:2,pts:0 }] },
  C: { teams: [{ name: "Brazil", flag: "🇧🇷", w:0,d:1,l:0,gf:1,ga:1,pts:1 }, { name: "Morocco", flag: "🇲🇦", w:0,d:1,l:0,gf:1,ga:1,pts:1 }, { name: "Scotland", flag: "🏴󠁧󠁢󠁳󠁣󠁴󠁿", w:1,d:0,l:0,gf:1,ga:0,pts:3 }, { name: "Haiti", flag: "🇭🇹", w:0,d:0,l:1,gf:0,ga:1,pts:0 }] },
  D: { teams: [{ name: "USA", flag: "🇺🇸", w:1,d:0,l:0,gf:4,ga:1,pts:3 }, { name: "Australia", flag: "🇦🇺", w:1,d:0,l:0,gf:2,ga:0,pts:3 }, { name: "Paraguay", flag: "🇵🇾", w:0,d:0,l:1,gf:1,ga:4,pts:0 }, { name: "Turkey", flag: "🇹🇷", w:0,d:0,l:1,gf:0,ga:2,pts:0 }] },
  E: { teams: [{ name: "Germany", flag: "🇩🇪", w:0,d:0,l:0,gf:0,ga:0,pts:0 }, { name: "Ecuador", flag: "🇪🇨", w:0,d:0,l:0,gf:0,ga:0,pts:0 }, { name: "Côte d'Ivoire", flag: "🇨🇮", w:0,d:0,l:0,gf:0,ga:0,pts:0 }, { name: "Curaçao", flag: "🇨🇼", w:0,d:0,l:0,gf:0,ga:0,pts:0 }] },
  F: { teams: [{ name: "Netherlands", flag: "🇳🇱", w:0,d:0,l:0,gf:0,ga:0,pts:0 }, { name: "Japan", flag: "🇯🇵", w:0,d:0,l:0,gf:0,ga:0,pts:0 }, { name: "Sweden", flag: "🇸🇪", w:0,d:0,l:0,gf:0,ga:0,pts:0 }, { name: "Tunisia", flag: "🇹🇳", w:0,d:0,l:0,gf:0,ga:0,pts:0 }] },
  G: { teams: [{ name: "Belgium", flag: "🇧🇪", w:0,d:0,l:0,gf:0,ga:0,pts:0 }, { name: "Iran", flag: "🇮🇷", w:0,d:0,l:0,gf:0,ga:0,pts:0 }, { name: "Egypt", flag: "🇪🇬", w:0,d:0,l:0,gf:0,ga:0,pts:0 }, { name: "New Zealand", flag: "🇳🇿", w:0,d:0,l:0,gf:0,ga:0,pts:0 }] },
  H: { teams: [{ name: "Spain", flag: "🇪🇸", w:0,d:0,l:0,gf:0,ga:0,pts:0 }, { name: "Uruguay", flag: "🇺🇾", w:0,d:0,l:0,gf:0,ga:0,pts:0 }, { name: "Saudi Arabia", flag: "🇸🇦", w:0,d:0,l:0,gf:0,ga:0,pts:0 }, { name: "Cape Verde", flag: "🇨🇻", w:0,d:0,l:0,gf:0,ga:0,pts:0 }] },
  I: { teams: [{ name: "France", flag: "🇫🇷", w:0,d:0,l:0,gf:0,ga:0,pts:0 }, { name: "Norway", flag: "🇳🇴", w:0,d:0,l:0,gf:0,ga:0,pts:0 }, { name: "Senegal", flag: "🇸🇳", w:0,d:0,l:0,gf:0,ga:0,pts:0 }, { name: "Iraq", flag: "🇮🇶", w:0,d:0,l:0,gf:0,ga:0,pts:0 }] },
  J: { teams: [{ name: "Argentina", flag: "🇦🇷", w:0,d:0,l:0,gf:0,ga:0,pts:0 }, { name: "Algeria", flag: "🇩🇿", w:0,d:0,l:0,gf:0,ga:0,pts:0 }, { name: "Austria", flag: "🇦🇹", w:0,d:0,l:0,gf:0,ga:0,pts:0 }, { name: "Jordan", flag: "🇯🇴", w:0,d:0,l:0,gf:0,ga:0,pts:0 }] },
  K: { teams: [{ name: "Colombia", flag: "🇨🇴", w:0,d:0,l:0,gf:0,ga:0,pts:0 }, { name: "Portugal", flag: "🇵🇹", w:0,d:0,l:0,gf:0,ga:0,pts:0 }, { name: "DR Congo", flag: "🇨🇩", w:0,d:0,l:0,gf:0,ga:0,pts:0 }, { name: "Cameroon", flag: "🇨🇲", w:0,d:0,l:0,gf:0,ga:0,pts:0 }] },
  L: { teams: [{ name: "England", flag: "🏴󠁧󠁢󠁥󠁮󠁧󠁿", w:0,d:0,l:0,gf:0,ga:0,pts:0 }, { name: "Croatia", flag: "🇭🇷", w:0,d:0,l:0,gf:0,ga:0,pts:0 }, { name: "Ghana", flag: "🇬🇭", w:0,d:0,l:0,gf:0,ga:0,pts:0 }, { name: "Panama", flag: "🇵🇦", w:0,d:0,l:0,gf:0,ga:0,pts:0 }] },
};

const FIXTURES = [
  { id:1, date:"Jun 11", time:"21:00 ET", home:"Mexico", homeFlag:"🇲🇽", away:"South Africa", awayFlag:"🇿🇦", hScore:2, aScore:0, group:"A", venue:"Estadio Azteca, Mexico City", status:"FT" },
  { id:2, date:"Jun 12", time:"15:00 ET", home:"USA", homeFlag:"🇺🇸", away:"Paraguay", awayFlag:"🇵🇾", hScore:4, aScore:1, group:"D", venue:"SoFi Stadium, LA", status:"FT" },
  { id:3, date:"Jun 12", time:"15:00 ET", home:"Canada", homeFlag:"🇨🇦", away:"Bosnia & Herz.", awayFlag:"🇧🇦", hScore:1, aScore:1, group:"B", venue:"BMO Field, Toronto", status:"FT" },
  { id:4, date:"Jun 13", time:"15:00 ET", home:"Haiti", homeFlag:"🇭🇹", away:"Scotland", awayFlag:"🏴󠁧󠁢󠁳󠁣󠁴󠁿", hScore:0, aScore:1, group:"C", venue:"Gillette Stadium, Boston", status:"FT" },
  { id:5, date:"Jun 13", time:"18:00 ET", home:"Australia", homeFlag:"🇦🇺", away:"Turkey", awayFlag:"🇹🇷", hScore:2, aScore:0, group:"D", venue:"BC Place, Vancouver", status:"FT" },
  { id:6, date:"Jun 13", time:"18:00 ET", home:"Brazil", homeFlag:"🇧🇷", away:"Morocco", awayFlag:"🇲🇦", hScore:1, aScore:1, group:"C", venue:"MetLife Stadium, NJ", status:"FT" },
  { id:7, date:"Jun 14", time:"12:00 ET", home:"South Africa", homeFlag:"🇿🇦", away:"South Korea", awayFlag:"🇰🇷", hScore:1, aScore:1, group:"A", venue:"Levi's Stadium, SF", status:"FT" },
  { id:8, date:"Jun 14", time:"15:00 ET", home:"Qatar", homeFlag:"🇶🇦", away:"Switzerland", awayFlag:"🇨🇭", hScore:0, aScore:2, group:"B", venue:"Lumen Field, Seattle", status:"FT" },
  { id:9, date:"Jun 15", time:"15:00 ET", home:"Côte d'Ivoire", homeFlag:"🇨🇮", away:"Ecuador", awayFlag:"🇪🇨", hScore:null, aScore:null, group:"E", venue:"Lincoln Financial, Philadelphia", status:"TODAY" },
  { id:10, date:"Jun 15", time:"18:00 ET", home:"Germany", homeFlag:"🇩🇪", away:"Curaçao", awayFlag:"🇨🇼", hScore:null, aScore:null, group:"E", venue:"NRG Stadium, Houston", status:"TODAY" },
  { id:11, date:"Jun 15", time:"21:00 ET", home:"Belgium", homeFlag:"🇧🇪", away:"New Zealand", awayFlag:"🇳🇿", hScore:null, aScore:null, group:"G", venue:"BC Place, Vancouver", status:"TODAY" },
  { id:12, date:"Jun 16", time:"15:00 ET", home:"Japan", homeFlag:"🇯🇵", away:"Sweden", awayFlag:"🇸🇪", hScore:null, aScore:null, group:"F", venue:"AT&T Stadium, Dallas", status:"UPCOMING" },
  { id:13, date:"Jun 16", time:"18:00 ET", home:"France", homeFlag:"🇫🇷", away:"Iraq", awayFlag:"🇮🇶", hScore:null, aScore:null, group:"I", venue:"Lincoln Financial, Philadelphia", status:"UPCOMING" },
  { id:14, date:"Jun 17", time:"15:00 ET", home:"England", homeFlag:"🏴󠁧󠁢󠁥󠁮󠁧󠁿", away:"Croatia", awayFlag:"🇭🇷", hScore:null, aScore:null, group:"L", venue:"AT&T Stadium, Dallas", status:"UPCOMING" },
  { id:15, date:"Jun 17", time:"18:00 ET", home:"Argentina", homeFlag:"🇦🇷", away:"Austria", awayFlag:"🇦🇹", hScore:null, aScore:null, group:"J", venue:"Mercedes-Benz Stadium, Atlanta", status:"UPCOMING" },
];

const SCORERS = [
  { name:"Christian Pulisic", flag:"🇺🇸", team:"USA", goals:2, assists:1 },
  { name:"Timothy Weah", flag:"🇺🇸", team:"USA", goals:1, assists:0 },
  { name:"Javier Hernández", flag:"🇲🇽", team:"Mexico", goals:1, assists:1 },
  { name:"Lamine Yamal", flag:"🇪🇸", team:"Spain", goals:0, assists:0 },
  { name:"Kylian Mbappé", flag:"🇫🇷", team:"France", goals:0, assists:0 },
  { name:"Lionel Messi", flag:"🇦🇷", team:"Argentina", goals:0, assists:0 },
];

const HIGHLIGHTS = [
  { id:1, title:"Mexico 2-0 South Africa — Opening Ceremony & Goals", match:"Group A", date:"Jun 11", thumb:"🇲🇽", ytId:"dQw4w9WgXcQ" },
  { id:2, title:"USA 4-1 Paraguay — All Goals & Highlights", match:"Group D", date:"Jun 12", thumb:"🇺🇸", ytId:"dQw4w9WgXcQ" },
  { id:3, title:"Brazil 1-1 Morocco — Thrilling Draw at MetLife", match:"Group C", date:"Jun 13", thumb:"🇧🇷", ytId:"dQw4w9WgXcQ" },
  { id:4, title:"Canada 1-1 Bosnia — Late Equalizer Drama", match:"Group B", date:"Jun 12", thumb:"🇨🇦", ytId:"dQw4w9WgXcQ" },
];

const NEWS = [
  { id:1, time:"2h ago", tag:"RESULT", color:"#10b981", headline:"USA storm to 4-1 win over Paraguay in World Cup opener", body:"Christian Pulisic scored twice as the United States delivered a stunning Group D statement victory at SoFi Stadium in Los Angeles." },
  { id:2, time:"4h ago", tag:"RESULT", color:"#10b981", headline:"Brazil held by Morocco in Group C thriller", body:"A late equalizer from Morocco denied Brazil a winning start. The match at MetLife Stadium drew 1-1 in a tense, physical encounter." },
  { id:3, time:"5h ago", tag:"RESULT", color:"#10b981", headline:"Scotland upset Haiti 1-0 in Boston opener", body:"Scotland grabbed an early goal and held on for a disciplined Group C victory at Gillette Stadium." },
  { id:4, time:"8h ago", tag:"RESULT", color:"#10b981", headline:"Mexico kick off World Cup with 2-0 win over South Africa", body:"Mexico opened the tournament at Estadio Azteca with a professional display, goals in each half sealing a comfortable Group A victory." },
  { id:5, time:"1d ago", tag:"PREVIEW", color:"#3b82f6", headline:"Germany vs Curaçao: Can the four-time champions start strong?", body:"Germany face Curaçao today in Houston, Group E. Expect a high-scoring opener as Germany look to stake their title claim early." },
  { id:6, time:"1d ago", tag:"PREVIEW", color:"#3b82f6", headline:"Belgium, France, Argentina all in action from Jun 15-17", body:"The tournament's big guns enter the fray this week. Watch all highlights live on Budro26 World Cup on YouTube." },
  { id:7, time:"2d ago", tag:"TOURNAMENT", color:"#c9a227", headline:"48 teams, 104 matches — the biggest World Cup ever begins", body:"FIFA's expanded 48-team format kicks off across 16 stadiums in the USA, Canada and Mexico through to the July 19 final." },
];

// Knockout bracket data - Round of 32 slots (TBD until group stage ends)
const BRACKET_ROUNDS = [
  {
    label: "Round of 32", short: "R32", date: "Jun 27 – Jul 2",
    matches: [
      { home:"1A", away:"3D/E/F", hScore:null, aScore:null },
      { home:"1B", away:"3A/C/D", hScore:null, aScore:null },
      { home:"1C", away:"3G/H/I", hScore:null, aScore:null },
      { home:"1D", away:"3J/K/L", hScore:null, aScore:null },
      { home:"1E", away:"2H", hScore:null, aScore:null },
      { home:"1F", away:"2G", hScore:null, aScore:null },
      { home:"1G", away:"2F", hScore:null, aScore:null },
      { home:"1H", away:"2E", hScore:null, aScore:null },
      { home:"1I", away:"2L", hScore:null, aScore:null },
      { home:"1J", away:"2K", hScore:null, aScore:null },
      { home:"1K", away:"2J", hScore:null, aScore:null },
      { home:"1L", away:"2I", hScore:null, aScore:null },
      { home:"2A", away:"2B", hScore:null, aScore:null },
      { home:"2C", away:"2D", hScore:null, aScore:null },
      { home:"3rd Best 1", away:"3rd Best 2", hScore:null, aScore:null },
      { home:"3rd Best 3", away:"3rd Best 4", hScore:null, aScore:null },
    ]
  },
  {
    label: "Round of 16", short: "R16", date: "Jul 3–6",
    matches: [
      { home:"W1", away:"W2", hScore:null, aScore:null },
      { home:"W3", away:"W4", hScore:null, aScore:null },
      { home:"W5", away:"W6", hScore:null, aScore:null },
      { home:"W7", away:"W8", hScore:null, aScore:null },
      { home:"W9", away:"W10", hScore:null, aScore:null },
      { home:"W11", away:"W12", hScore:null, aScore:null },
      { home:"W13", away:"W14", hScore:null, aScore:null },
      { home:"W15", away:"W16", hScore:null, aScore:null },
    ]
  },
  {
    label: "Quarter-Finals", short: "QF", date: "Jul 9–11",
    matches: [
      { home:"QF1", away:"QF2", hScore:null, aScore:null },
      { home:"QF3", away:"QF4", hScore:null, aScore:null },
      { home:"QF5", away:"QF6", hScore:null, aScore:null },
      { home:"QF7", away:"QF8", hScore:null, aScore:null },
    ]
  },
  {
    label: "Semi-Finals", short: "SF", date: "Jul 14–15",
    matches: [
      { home:"SF1", away:"SF2", hScore:null, aScore:null },
      { home:"SF3", away:"SF4", hScore:null, aScore:null },
    ]
  },
  {
    label: "Final", short: "🏆", date: "Jul 19",
    matches: [
      { home:"Champion", away:"Runner-Up", hScore:null, aScore:null, isFinal:true },
    ]
  },
];

const NAV = ["Home", "Fixtures", "Standings", "Bracket", "Top Scorers", "Highlights", "News"];
const statusColor = (s) => s === "FT" ? "#10b981" : s === "TODAY" ? "#f59e0b" : "#6b7280";
const statusLabel = (s) => s === "FT" ? "Full Time" : s === "TODAY" ? "🔴 Today" : "Upcoming";

export default function App() {
  const [tab, setTab] = useState("Home");
  const [selGroup, setSelGroup] = useState("ALL");
  const [countdown, setCountdown] = useState("");
  const [ytModal, setYtModal] = useState(null);
  const [subscribed, setSubscribed] = useState(false);
  const [bracketRound, setBracketRound] = useState(0);

  useEffect(() => {
    const target = new Date("2026-06-15T19:00:00-05:00");
    const tick = () => {
      const diff = target - new Date();
      if (diff <= 0) { setCountdown("LIVE NOW 🔴"); return; }
      const h = Math.floor(diff / 3600000);
      const m = Math.floor((diff % 3600000) / 60000);
      const s = Math.floor((diff % 60000) / 1000);
      setCountdown(`${h}h ${m}m ${s}s`);
    };
    tick();
    const t = setInterval(tick, 1000);
    return () => clearInterval(t);
  }, []);

  const filtered = selGroup === "ALL" ? FIXTURES : FIXTURES.filter(f => f.group === selGroup);
  const todayMatches = FIXTURES.filter(f => f.status === "TODAY");
  const recentResults = FIXTURES.filter(f => f.status === "FT").slice(-3).reverse();

  return (
    <div style={{ fontFamily:"'Segoe UI',system-ui,sans-serif", background:"#080b12", minHeight:"100vh", color:"#f1f5f9" }}>

      {/* HERO */}
      <div style={{
        background:"linear-gradient(160deg,#0f0c29 0%,#141428 50%,#0f0c29 100%)",
        borderBottom:"2px solid #c9a227", position:"relative", overflow:"hidden"
      }}>
        <div style={{ position:"absolute", inset:0, backgroundImage:"radial-gradient(ellipse at 15% 60%,rgba(201,162,39,0.1) 0%,transparent 55%),radial-gradient(ellipse at 85% 40%,rgba(220,38,38,0.1) 0%,transparent 55%)" }}/>
        {/* Stars */}
        {[...Array(18)].map((_,i) => (
          <div key={i} style={{ position:"absolute", width:2, height:2, borderRadius:"50%", background:"rgba(255,255,255,0.3)",
            top:`${Math.random()*100}%`, left:`${Math.random()*100}%` }}/>
        ))}
        <div style={{ maxWidth:1140, margin:"0 auto", padding:"28px 20px 0", position:"relative" }}>
          <div style={{ display:"flex", alignItems:"center", gap:18, flexWrap:"wrap" }}>
            <div style={{ fontSize:56, filter:"drop-shadow(0 0 20px rgba(201,162,39,0.5))" }}>🏆</div>
            <div>
              <div style={{ fontSize:10, letterSpacing:5, color:"#c9a227", textTransform:"uppercase", fontWeight:800 }}>FIFA Official</div>
              <h1 style={{ margin:"2px 0", fontSize:"clamp(22px,5vw,44px)", fontWeight:900, lineHeight:1,
                background:"linear-gradient(90deg,#ffffff 0%,#c9a227 60%,#ff6b35 100%)",
                WebkitBackgroundClip:"text", WebkitTextFillColor:"transparent" }}>
                World Cup 2026™
              </h1>
              <div style={{ fontSize:12, color:"#64748b", marginTop:4 }}>USA · Canada · Mexico &nbsp;|&nbsp; Jun 11 – Jul 19, 2026 &nbsp;|&nbsp; 48 Teams · 104 Matches</div>
            </div>
            <div style={{ marginLeft:"auto", textAlign:"right", minWidth:160 }}>
              <div style={{ fontSize:10, color:"#64748b", letterSpacing:3, textTransform:"uppercase" }}>Next Kick-Off</div>
              <div style={{ fontSize:13, color:"#e2e8f0", fontWeight:700, marginTop:2 }}>🇨🇮 CIV vs ECU 🇪🇨</div>
              <div style={{ fontSize:20, fontWeight:900, color:"#f59e0b", fontVariantNumeric:"tabular-nums", letterSpacing:1 }}>{countdown}</div>
            </div>
          </div>

          {/* NAV */}
          <div style={{ display:"flex", gap:2, marginTop:22, borderTop:"1px solid rgba(255,255,255,0.07)", paddingTop:14, flexWrap:"wrap" }}>
            {NAV.map(n => (
              <button key={n} onClick={() => setTab(n)} style={{
                padding:"8px 16px", borderRadius:"6px 6px 0 0", border:"none", cursor:"pointer",
                fontWeight:700, fontSize:12, transition:"all .18s", letterSpacing:.3,
                background: tab===n ? "#c9a227" : "transparent",
                color: tab===n ? "#080b12" : "#64748b",
                borderBottom: tab===n ? "none" : "2px solid transparent",
              }}>{n}</button>
            ))}
          </div>
        </div>
      </div>

      {/* YOUTUBE SUBSCRIBE BANNER */}
      <div style={{
        background:"linear-gradient(90deg,#1a0000 0%,#ff0000 30%,#cc0000 70%,#1a0000 100%)",
        borderBottom:"1px solid rgba(255,0,0,0.3)", padding:"10px 20px",
        display:"flex", alignItems:"center", justifyContent:"center", gap:16, flexWrap:"wrap"
      }}>
        <div style={{ display:"flex", alignItems:"center", gap:10 }}>
          <div style={{ width:36, height:36, borderRadius:"50%", background:"rgba(255,255,255,0.15)", display:"flex", alignItems:"center", justifyContent:"center", fontSize:20 }}>📺</div>
          <div>
            <div style={{ fontWeight:800, fontSize:13, color:"#fff" }}>Budro26 World Cup</div>
            <div style={{ fontSize:11, color:"rgba(255,255,255,0.7)" }}>Goals · Highlights · Analysis — Every Match Covered</div>
          </div>
        </div>
        <a href={YT_CHANNEL} target="_blank" rel="noreferrer" style={{ textDecoration:"none" }}>
          <button
            onClick={() => setSubscribed(true)}
            style={{
              background: subscribed ? "#555" : "#fff",
              color: subscribed ? "#fff" : "#ff0000",
              border:"none", borderRadius:24, padding:"8px 22px",
              fontWeight:800, fontSize:13, cursor:"pointer", transition:"all .2s",
              display:"flex", alignItems:"center", gap:6
            }}
          >
            {subscribed ? "✓ Subscribed!" : "▶ SUBSCRIBE"}
          </button>
        </a>
        <div style={{ fontSize:11, color:"rgba(255,255,255,0.5)" }}>Watch all highlights on YouTube →</div>
      </div>

      <div style={{ maxWidth:1140, margin:"0 auto", padding:"24px 20px 60px" }}>

        {/* HOME TAB */}
        {tab === "Home" && (
          <div style={{ display:"grid", gap:20 }}>
            {/* Today's matches */}
            <div>
              <h2 style={{ margin:"0 0 14px", fontSize:16, fontWeight:800, color:"#f59e0b", display:"flex", alignItems:"center", gap:8 }}>
                🔴 Today's Matches — June 15
              </h2>
              <div style={{ display:"grid", gap:10 }}>
                {todayMatches.map(f => (
                  <div key={f.id} style={{ background:"rgba(245,158,11,0.06)", border:"1px solid rgba(245,158,11,0.25)", borderRadius:12, padding:"16px 20px" }}>
                    <div style={{ display:"flex", justifyContent:"space-between", flexWrap:"wrap", gap:10 }}>
                      <div style={{ display:"flex", alignItems:"center", gap:10, flex:1 }}>
                        <span style={{ fontSize:26 }}>{f.homeFlag}</span>
                        <span style={{ fontWeight:700 }}>{f.home}</span>
                      </div>
                      <div style={{ background:"rgba(0,0,0,0.5)", borderRadius:8, padding:"6px 14px", textAlign:"center" }}>
                        <div style={{ fontSize:11, color:"#f59e0b", fontWeight:700 }}>{f.time}</div>
                        <div style={{ fontSize:13, color:"#64748b" }}>vs</div>
                      </div>
                      <div style={{ display:"flex", alignItems:"center", gap:10, flex:1, justifyContent:"flex-end" }}>
                        <span style={{ fontWeight:700 }}>{f.away}</span>
                        <span style={{ fontSize:26 }}>{f.awayFlag}</span>
                      </div>
                    </div>
                    <div style={{ marginTop:8, fontSize:11, color:"#334155" }}>📍 {f.venue} · Group {f.group}</div>
                  </div>
                ))}
              </div>
            </div>

            {/* Recent Results */}
            <div>
              <h2 style={{ margin:"0 0 14px", fontSize:16, fontWeight:800, color:"#10b981", display:"flex", alignItems:"center", gap:8 }}>
                ✅ Latest Results
              </h2>
              <div style={{ display:"grid", gap:10 }}>
                {recentResults.map(f => (
                  <div key={f.id} style={{ background:"rgba(16,185,129,0.04)", border:"1px solid rgba(16,185,129,0.15)", borderRadius:12, padding:"14px 20px", display:"flex", alignItems:"center", gap:12, flexWrap:"wrap" }}>
                    <span style={{ fontSize:11, background:"rgba(16,185,129,0.15)", color:"#10b981", padding:"2px 8px", borderRadius:20, fontWeight:700, whiteSpace:"nowrap" }}>Group {f.group} FT</span>
                    <div style={{ display:"flex", alignItems:"center", gap:8, flex:1, flexWrap:"wrap", justifyContent:"center" }}>
                      <span style={{ fontSize:22 }}>{f.homeFlag}</span>
                      <span style={{ fontWeight:700, fontSize:14 }}>{f.home}</span>
                      <span style={{ fontWeight:900, fontSize:20, background:"rgba(0,0,0,0.4)", padding:"4px 14px", borderRadius:6, letterSpacing:3 }}>{f.hScore} – {f.aScore}</span>
                      <span style={{ fontWeight:700, fontSize:14 }}>{f.away}</span>
                      <span style={{ fontSize:22 }}>{f.awayFlag}</span>
                    </div>
                    <span style={{ fontSize:11, color:"#334155", whiteSpace:"nowrap" }}>{f.date}</span>
                  </div>
                ))}
              </div>
            </div>

            {/* Latest news preview */}
            <div>
              <div style={{ display:"flex", justifyContent:"space-between", alignItems:"center", marginBottom:14 }}>
                <h2 style={{ margin:0, fontSize:16, fontWeight:800, color:"#f1f5f9" }}>📰 Latest News</h2>
                <button onClick={() => setTab("News")} style={{ background:"none", border:"1px solid rgba(255,255,255,0.1)", borderRadius:6, color:"#64748b", padding:"4px 12px", fontSize:12, cursor:"pointer" }}>See all →</button>
              </div>
              {NEWS.slice(0,3).map(n => (
                <div key={n.id} style={{ borderLeft:"3px solid " + n.color, paddingLeft:14, marginBottom:16 }}>
                  <div style={{ display:"flex", gap:8, alignItems:"center", marginBottom:4 }}>
                    <span style={{ fontSize:10, background: n.color + "22", color:n.color, padding:"2px 7px", borderRadius:20, fontWeight:700 }}>{n.tag}</span>
                    <span style={{ fontSize:11, color:"#334155" }}>{n.time}</span>
                  </div>
                  <div style={{ fontWeight:700, fontSize:14, color:"#e2e8f0", lineHeight:1.4 }}>{n.headline}</div>
                  <div style={{ fontSize:12, color:"#475569", marginTop:4, lineHeight:1.5 }}>{n.body}</div>
                </div>
              ))}
            </div>
          </div>
        )}

        {/* FIXTURES TAB */}
        {tab === "Fixtures" && (
          <div>
            <div style={{ display:"flex", alignItems:"center", gap:6, marginBottom:18, flexWrap:"wrap" }}>
              <span style={{ fontSize:12, color:"#475569", marginRight:4 }}>Group:</span>
              {["ALL","A","B","C","D","E","F","G","H","I","J","K","L"].map(g => (
                <button key={g} onClick={() => setSelGroup(g)} style={{
                  padding:"4px 11px", borderRadius:20, border:"1px solid",
                  borderColor: selGroup===g ? "#c9a227" : "rgba(255,255,255,0.08)",
                  background: selGroup===g ? "rgba(201,162,39,0.15)" : "transparent",
                  color: selGroup===g ? "#c9a227" : "#475569",
                  fontSize:12, fontWeight:700, cursor:"pointer"
                }}>{g}</button>
              ))}
            </div>
            <div style={{ display:"grid", gap:10 }}>
              {filtered.map(f => (
                <div key={f.id} style={{
                  background:"rgba(255,255,255,0.025)", border:"1px solid rgba(255,255,255,0.07)",
                  borderRadius:12, padding:"14px 18px", borderLeft:`3px solid ${statusColor(f.status)}`
                }}>
                  <div style={{ display:"flex", justifyContent:"space-between", alignItems:"center", flexWrap:"wrap", gap:8, marginBottom:10 }}>
                    <div style={{ display:"flex", gap:8 }}>
                      <span style={{ fontSize:11, background:"rgba(201,162,39,0.12)", color:"#c9a227", padding:"2px 8px", borderRadius:20, fontWeight:700 }}>Group {f.group}</span>
                      <span style={{ fontSize:11, color:"#334155" }}>{f.date} · {f.time}</span>
                    </div>
                    <span style={{ fontSize:11, color:statusColor(f.status), fontWeight:700 }}>{statusLabel(f.status)}</span>
                  </div>
                  <div style={{ display:"flex", alignItems:"center", justifyContent:"space-between", gap:8 }}>
                    <div style={{ display:"flex", alignItems:"center", gap:10, flex:1 }}>
                      <span style={{ fontSize:26 }}>{f.homeFlag}</span>
                      <span style={{ fontWeight:700, fontSize:14 }}>{f.home}</span>
                    </div>
                    <div style={{ background:"rgba(0,0,0,0.5)", borderRadius:8, padding:"6px 16px", textAlign:"center", minWidth:72 }}>
                      {f.hScore !== null
                        ? <span style={{ fontSize:20, fontWeight:900, letterSpacing:4 }}>{f.hScore}–{f.aScore}</span>
                        : <span style={{ fontSize:12, color:"#334155" }}>vs</span>}
                    </div>
                    <div style={{ display:"flex", alignItems:"center", gap:10, flex:1, justifyContent:"flex-end" }}>
                      <span style={{ fontWeight:700, fontSize:14 }}>{f.away}</span>
                      <span style={{ fontSize:26 }}>{f.awayFlag}</span>
                    </div>
                  </div>
                  <div style={{ marginTop:8, fontSize:11, color:"#1e293b" }}>📍 {f.venue}</div>
                </div>
              ))}
            </div>
          </div>
        )}

        {/* STANDINGS TAB */}
        {tab === "Standings" && (
          <div style={{ display:"grid", gridTemplateColumns:"repeat(auto-fill,minmax(310px,1fr))", gap:14 }}>
            {Object.entries(GROUPS).map(([grp, data]) => (
              <div key={grp} style={{ background:"rgba(255,255,255,0.025)", border:"1px solid rgba(255,255,255,0.07)", borderRadius:12, overflow:"hidden" }}>
                <div style={{ background:"rgba(201,162,39,0.1)", borderBottom:"1px solid rgba(201,162,39,0.18)", padding:"9px 14px" }}>
                  <span style={{ fontWeight:900, color:"#c9a227", fontSize:16 }}>Group {grp}</span>
                </div>
                <table style={{ width:"100%", borderCollapse:"collapse", fontSize:12 }}>
                  <thead>
                    <tr style={{ color:"#334155" }}>
                      <th style={{ padding:"7px 14px", textAlign:"left" }}>Team</th>
                      <th style={{ padding:"7px 6px", textAlign:"center" }}>W</th>
                      <th style={{ padding:"7px 6px", textAlign:"center" }}>D</th>
                      <th style={{ padding:"7px 6px", textAlign:"center" }}>L</th>
                      <th style={{ padding:"7px 6px", textAlign:"center" }}>GD</th>
                      <th style={{ padding:"7px 14px", textAlign:"center", color:"#c9a227", fontWeight:800 }}>PTS</th>
                    </tr>
                  </thead>
                  <tbody>
                    {[...data.teams].sort((a,b)=>b.pts-a.pts||(b.gf-b.ga)-(a.gf-a.ga)).map((t,i) => (
                      <tr key={t.name} style={{ borderTop:"1px solid rgba(255,255,255,0.04)", background:i<2?"rgba(201,162,39,0.04)":"transparent" }}>
                        <td style={{ padding:"8px 14px" }}>
                          <div style={{ display:"flex", alignItems:"center", gap:7 }}>
                            {i<2 && <span style={{ width:3, height:3, borderRadius:"50%", background:"#c9a227", display:"inline-block", flexShrink:0 }}/>}
                            <span style={{ fontSize:16 }}>{t.flag}</span>
                            <span style={{ fontWeight:i<2?700:400, fontSize:12 }}>{t.name}</span>
                          </div>
                        </td>
                        <td style={{ padding:"8px 6px", textAlign:"center", color:"#64748b" }}>{t.w}</td>
                        <td style={{ padding:"8px 6px", textAlign:"center", color:"#64748b" }}>{t.d}</td>
                        <td style={{ padding:"8px 6px", textAlign:"center", color:"#64748b" }}>{t.l}</td>
                        <td style={{ padding:"8px 6px", textAlign:"center", color:"#64748b" }}>{t.gf-t.ga>=0?`+${t.gf-t.ga}`:t.gf-t.ga}</td>
                        <td style={{ padding:"8px 14px", textAlign:"center", fontWeight:900, fontSize:14, color:t.pts>0?"#f1f5f9":"#334155" }}>{t.pts}</td>
                      </tr>
                    ))}
                  </tbody>
                </table>
                <div style={{ padding:"5px 14px 8px", fontSize:10, color:"#1e293b" }}>● Top 2 advance to Round of 32</div>
              </div>
            ))}
          </div>
        )}

        {/* BRACKET TAB */}
        {tab === "Bracket" && (
          <div>
            <div style={{ marginBottom:20 }}>
              <h2 style={{ margin:"0 0 6px", fontSize:18, fontWeight:900, color:"#c9a227" }}>🏆 Knockout Stage Bracket</h2>
              <p style={{ margin:0, fontSize:13, color:"#475569" }}>Group stage ends June 26 · Knockout rounds begin June 27 · Final: July 19, MetLife Stadium NJ</p>
            </div>

            {/* Round selector */}
            <div style={{ display:"flex", gap:6, marginBottom:20, flexWrap:"wrap" }}>
              {BRACKET_ROUNDS.map((r,i) => (
                <button key={i} onClick={() => setBracketRound(i)} style={{
                  padding:"7px 16px", borderRadius:8, border:"1px solid",
                  borderColor: bracketRound===i ? "#c9a227" : "rgba(255,255,255,0.08)",
                  background: bracketRound===i ? "rgba(201,162,39,0.15)" : "transparent",
                  color: bracketRound===i ? "#c9a227" : "#475569",
                  fontSize:12, fontWeight:700, cursor:"pointer"
                }}>{r.short}</button>
              ))}
            </div>

            {/* Round display */}
            {(() => {
              const r = BRACKET_ROUNDS[bracketRound];
              return (
                <div>
                  <div style={{ display:"flex", alignItems:"center", gap:12, marginBottom:16 }}>
                    <h3 style={{ margin:0, fontSize:16, fontWeight:900, color:"#f1f5f9" }}>{r.label}</h3>
                    <span style={{ fontSize:12, color:"#475569", background:"rgba(255,255,255,0.05)", padding:"3px 10px", borderRadius:20 }}>{r.date}</span>
                  </div>
                  <div style={{ display:"grid", gridTemplateColumns:"repeat(auto-fill,minmax(260px,1fr))", gap:10 }}>
                    {r.matches.map((m,i) => (
                      <div key={i} style={{
                        background: m.isFinal ? "linear-gradient(135deg,rgba(201,162,39,0.15),rgba(201,162,39,0.05))" : "rgba(255,255,255,0.03)",
                        border: m.isFinal ? "1px solid rgba(201,162,39,0.4)" : "1px solid rgba(255,255,255,0.07)",
                        borderRadius:10, overflow:"hidden"
                      }}>
                        {/* match number */}
                        <div style={{ background:"rgba(0,0,0,0.3)", padding:"5px 12px", fontSize:10, color:"#334155", fontWeight:700 }}>
                          {m.isFinal ? "🏆 THE FINAL · Jul 19, MetLife Stadium" : `Match ${i+1}`}
                        </div>
                        <div style={{ padding:"10px 12px" }}>
                          <div style={{ display:"flex", alignItems:"center", justifyContent:"space-between", gap:8, marginBottom:8 }}>
                            <span style={{ fontWeight:700, fontSize:13, color: m.isFinal ? "#c9a227" : "#e2e8f0", flex:1 }}>{m.home}</span>
                            <div style={{ background:"rgba(0,0,0,0.4)", borderRadius:6, padding:"4px 10px", textAlign:"center", minWidth:50 }}>
                              {m.hScore !== null
                                ? <span style={{ fontWeight:900, fontSize:16 }}>{m.hScore}–{m.aScore}</span>
                                : <span style={{ fontSize:11, color:"#334155" }}>TBD</span>}
                            </div>
                            <span style={{ fontWeight:700, fontSize:13, color: m.isFinal ? "#c9a227" : "#e2e8f0", flex:1, textAlign:"right" }}>{m.away}</span>
                          </div>
                        </div>
                      </div>
                    ))}
                  </div>
                  {bracketRound === 0 && (
                    <div style={{ marginTop:16, background:"rgba(201,162,39,0.06)", border:"1px solid rgba(201,162,39,0.15)", borderRadius:10, padding:"12px 16px", fontSize:12, color:"#64748b" }}>
                      ℹ️ Slots will be filled automatically once the group stage concludes on June 26. The 8 best third-place teams also advance.
                    </div>
                  )}
                </div>
              );
            })()}
          </div>
        )}

        {/* TOP SCORERS TAB */}
        {tab === "Top Scorers" && (
          <div style={{ display:"grid", gap:10 }}>
            {SCORERS.map((s,i) => (
              <div key={s.name} style={{
                background:"rgba(255,255,255,0.025)", border:"1px solid rgba(255,255,255,0.07)",
                borderRadius:12, padding:"14px 18px", display:"flex", alignItems:"center", gap:14
              }}>
                <div style={{ fontWeight:900, fontSize:22, color:i===0?"#c9a227":i===1?"#94a3b8":i===2?"#cd7f32":"#1e293b", minWidth:28, textAlign:"center" }}>{i+1}</div>
                <span style={{ fontSize:30 }}>{s.flag}</span>
                <div style={{ flex:1 }}>
                  <div style={{ fontWeight:700, fontSize:14 }}>{s.name}</div>
                  <div style={{ fontSize:12, color:"#475569" }}>{s.team}</div>
                </div>
                <div style={{ display:"flex", gap:16, textAlign:"center" }}>
                  <div><div style={{ fontSize:22, fontWeight:900, color:"#c9a227" }}>{s.goals}</div><div style={{ fontSize:10, color:"#475569" }}>Goals</div></div>
                  <div><div style={{ fontSize:22, fontWeight:900, color:"#3b82f6" }}>{s.assists}</div><div style={{ fontSize:10, color:"#475569" }}>Assists</div></div>
                </div>
              </div>
            ))}
          </div>
        )}

        {/* HIGHLIGHTS TAB */}
        {tab === "Highlights" && (
          <div>
            <div style={{ display:"flex", justifyContent:"space-between", alignItems:"center", marginBottom:18, flexWrap:"wrap", gap:10 }}>
              <h2 style={{ margin:0, fontSize:16, fontWeight:800 }}>🎬 Match Highlights</h2>
              <a href={YT_CHANNEL} target="_blank" rel="noreferrer" style={{ textDecoration:"none" }}>
                <button style={{ background:"#ff0000", color:"#fff", border:"none", borderRadius:8, padding:"8px 16px", fontWeight:800, fontSize:13, cursor:"pointer", display:"flex", alignItems:"center", gap:6 }}>
                  ▶ All Videos on YouTube
                </button>
              </a>
            </div>
            <div style={{ display:"grid", gridTemplateColumns:"repeat(auto-fill,minmax(270px,1fr))", gap:14 }}>
              {HIGHLIGHTS.map(h => (
                <div key={h.id}
                  style={{ background:"rgba(255,255,255,0.025)", border:"1px solid rgba(255,255,255,0.07)", borderRadius:14, overflow:"hidden", cursor:"pointer", transition:"transform .2s,border-color .2s" }}
                  onMouseEnter={e => { e.currentTarget.style.transform="translateY(-4px)"; e.currentTarget.style.borderColor="rgba(201,162,39,0.35)"; }}
                  onMouseLeave={e => { e.currentTarget.style.transform="none"; e.currentTarget.style.borderColor="rgba(255,255,255,0.07)"; }}
                  onClick={() => setYtModal(h)}
                >
                  <div style={{ height:150, background:"linear-gradient(135deg,#1a0a2e,#080b12)", display:"flex", alignItems:"center", justifyContent:"center", position:"relative" }}>
                    <span style={{ fontSize:52 }}>{h.thumb}</span>
                    <div style={{ position:"absolute", inset:0, display:"flex", alignItems:"center", justifyContent:"center", background:"rgba(0,0,0,0.25)" }}>
                      <div style={{ width:52, height:52, borderRadius:"50%", background:"rgba(255,0,0,0.9)", display:"flex", alignItems:"center", justifyContent:"center" }}>
                        <span style={{ color:"#fff", fontSize:18, marginLeft:4 }}>▶</span>
                      </div>
                    </div>
                    <div style={{ position:"absolute", top:8, right:8, background:"rgba(0,0,0,0.75)", borderRadius:4, padding:"2px 7px", fontSize:10, color:"#fff", fontWeight:700 }}>YouTube</div>
                  </div>
                  <div style={{ padding:"12px 14px" }}>
                    <div style={{ fontWeight:700, fontSize:13, lineHeight:1.4 }}>{h.title}</div>
                    <div style={{ marginTop:6, display:"flex", gap:7 }}>
                      <span style={{ fontSize:10, background:"rgba(201,162,39,0.12)", color:"#c9a227", padding:"2px 7px", borderRadius:20, fontWeight:700 }}>{h.match}</span>
                      <span style={{ fontSize:10, color:"#334155" }}>{h.date}</span>
                    </div>
                  </div>
                </div>
              ))}
              <div style={{ background:"rgba(255,255,255,0.02)", border:"2px dashed rgba(255,255,255,0.08)", borderRadius:14, display:"flex", flexDirection:"column", alignItems:"center", justifyContent:"center", minHeight:200, gap:8, color:"#1e293b", cursor:"pointer" }}>
                <div style={{ fontSize:32 }}>➕</div>
                <div style={{ fontSize:13, fontWeight:600, color:"#334155" }}>Add Highlight</div>
                <div style={{ fontSize:11, color:"#1e293b", textAlign:"center", padding:"0 16px" }}>Paste a YouTube link from your channel</div>
              </div>
            </div>
          </div>
        )}

        {/* NEWS TAB */}
        {tab === "News" && (
          <div>
            <h2 style={{ margin:"0 0 20px", fontSize:18, fontWeight:900 }}>📰 World Cup 2026 News & Updates</h2>
            <div style={{ display:"grid", gap:0 }}>
              {NEWS.map((n, i) => (
                <div key={n.id} style={{
                  padding:"20px 0", borderBottom:"1px solid rgba(255,255,255,0.06)",
                  display:"grid", gridTemplateColumns:"auto 1fr", gap:20, alignItems:"start"
                }}>
                  <div style={{ minWidth:56, textAlign:"center", paddingTop:3 }}>
                    <div style={{ fontSize:10, background:n.color+"22", color:n.color, padding:"3px 8px", borderRadius:20, fontWeight:800, whiteSpace:"nowrap" }}>{n.tag}</div>
                    <div style={{ fontSize:10, color:"#334155", marginTop:6 }}>{n.time}</div>
                  </div>
                  <div>
                    <div style={{ fontWeight:800, fontSize:15, color:"#e2e8f0", lineHeight:1.4, marginBottom:6 }}>{n.headline}</div>
                    <div style={{ fontSize:13, color:"#475569", lineHeight:1.6 }}>{n.body}</div>
                    {i === 0 && (
                      <a href={YT_CHANNEL} target="_blank" rel="noreferrer" style={{ textDecoration:"none" }}>
                        <div style={{ marginTop:10, display:"inline-flex", alignItems:"center", gap:6, background:"rgba(255,0,0,0.1)", border:"1px solid rgba(255,0,0,0.25)", borderRadius:6, padding:"5px 12px", fontSize:11, color:"#ff4444", fontWeight:700, cursor:"pointer" }}>
                          ▶ Watch highlights on Budro26 World Cup
                        </div>
                      </a>
                    )}
                  </div>
                </div>
              ))}
            </div>
          </div>
        )}
      </div>

      {/* YouTube Modal */}
      {ytModal && (
        <div style={{ position:"fixed", inset:0, background:"rgba(0,0,0,0.88)", display:"flex", alignItems:"center", justifyContent:"center", zIndex:200, padding:20 }}
          onClick={() => setYtModal(null)}>
          <div style={{ background:"#0d1117", borderRadius:16, overflow:"hidden", maxWidth:740, width:"100%", border:"1px solid rgba(201,162,39,0.25)" }}
            onClick={e => e.stopPropagation()}>
            <div style={{ padding:"14px 18px", display:"flex", justifyContent:"space-between", alignItems:"center", borderBottom:"1px solid rgba(255,255,255,0.07)" }}>
              <div>
                <div style={{ fontWeight:700, fontSize:14 }}>{ytModal.title}</div>
                <div style={{ fontSize:11, color:"#334155" }}>{ytModal.match} · {ytModal.date}</div>
              </div>
              <button onClick={() => setYtModal(null)} style={{ background:"none", border:"none", color:"#475569", fontSize:22, cursor:"pointer", lineHeight:1 }}>✕</button>
            </div>
            <div style={{ position:"relative", paddingBottom:"56.25%", background:"#000" }}>
              <iframe style={{ position:"absolute", inset:0, width:"100%", height:"100%", border:"none" }}
                src={`https://www.youtube.com/embed/${ytModal.ytId}?autoplay=1`}
                allow="autoplay; encrypted-media" allowFullScreen title={ytModal.title}/>
            </div>
            <div style={{ padding:"12px 18px", display:"flex", justifyContent:"center" }}>
              <a href={YT_CHANNEL} target="_blank" rel="noreferrer" style={{ textDecoration:"none" }}>
                <button style={{ background:"#ff0000", color:"#fff", border:"none", borderRadius:8, padding:"8px 20px", fontWeight:800, fontSize:13, cursor:"pointer" }}>
                  ▶ Subscribe to Budro26 World Cup
                </button>
              </a>
            </div>
          </div>
        </div>
      )}

      {/* FOOTER */}
      <div style={{ borderTop:"1px solid rgba(255,255,255,0.05)", padding:"20px", textAlign:"center" }}>
        <div style={{ fontSize:12, color:"#1e293b" }}>
          World Cup 2026 Hub · <a href={YT_CHANNEL} target="_blank" rel="noreferrer" style={{ color:"#ff4444", textDecoration:"none", fontWeight:700 }}>📺 Budro26 World Cup on YouTube</a> · Stats update after every match
        </div>
        <div style={{ fontSize:11, color:"#0f172a", marginTop:4 }}>🏆 48 teams · 104 matches · Final: July 19, MetLife Stadium, New Jersey</div>
      </div>
    </div>
  );
}
